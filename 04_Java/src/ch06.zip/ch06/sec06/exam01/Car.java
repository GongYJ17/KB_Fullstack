package ch06.sec06.exam01;

public class Car {
    String model; // null
    boolean start; // false
    int speed; // 0
    // 초기값으로 model은 null, start는 false, int는 0을 가진다.
}
