const { animals, showAnimals } = require('./commonAnimal');

console.log(animals);
showAnimals();

// const animals = require('./commonAnimal');

// console.log(animals.animals);
// animals.showAnimals();
