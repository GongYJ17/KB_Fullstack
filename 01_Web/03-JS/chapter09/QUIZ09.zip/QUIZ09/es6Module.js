import { animals, showAnimals } from './es6Animals.js';

console.log(animals);
showAnimals();
